package com.jzm.backme.service;

import com.jzm.backme.domain.Role;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  角色表 服务类
 * </p>
 *
 * @author qhx2004
 * @since 2024-04-14
 */
public interface RoleService extends IService<Role> {

}
