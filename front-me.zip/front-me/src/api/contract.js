import request from "@/utils/request";

let urlPrefix = '/contract'


function getAllContract(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/getAll`,
        data
    })
}


function createContract(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}



function backPrestoreMoney(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/backPrestoreMoney`,
        data
    })
}


function landlordPrestore(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/landlordPrestore`,
        data
    })
}


function tenantPrestore(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/tenantPrestore`,
        data
    })
}

function signContract(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/sign`,
        data
    })
}


function stopContract(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/stop`,
        data
    })
}





export {
    getAllContract,
    createContract,
    signContract,
    landlordPrestore,
    tenantPrestore,
    stopContract,
    backPrestoreMoney,
}