import request from "@/utils/request";

let urlPrefix = '/house'


function getAllHouse(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/getAll`,
        data
    })
}


function createHouse(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeHouse(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}


function updateHouse(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}

function updateHouseStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/updateStatus`,
        data
    })
}


function updatePass(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/updatePass`,
        data
    })
}


export {
    getAllHouse,
    removeHouse,
    updateHouse,
    updatePass,
    updateHouseStatus,
    createHouse,
}