import request from "@/utils/request";

let urlPrefix = '/user'


function getAllUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/getAll`,
        data
    })
}


function createUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}


function removeUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/delete`,
        data
    })
}


function updateUser(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/update`,
        data
    })
}

function updateUserStatus(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/updateStatus`,
        data
    })
}


function updatePass(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/updatePass`,
        data
    })
}
function payMoney(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/payMoney`,
        data
    })
}



// payMoney


export {
    getAllUser,
    removeUser,
    updateUser,
    updatePass,
    payMoney,
    updateUserStatus,
    createUser,
}