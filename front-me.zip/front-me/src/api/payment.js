import request from "@/utils/request";

let urlPrefix = '/payment'


function getAllPayment(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/getAll`,
        data
    })
}


function createPayment(data) {
    return request({
        method: 'post',
        url: `${urlPrefix}/create`,
        data
    })
}





export {
    getAllPayment,
    createPayment,
}