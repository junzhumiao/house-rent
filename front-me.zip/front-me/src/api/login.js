import request from "@/utils/request";



function getCaptcha() {

    return request({
        method: 'get',
        url: '/get/captcha',
    })

}

function submitLogin({ code, form }) {
    return request({
        method: 'post',
        url: '/login',
        headers: {
            "captcha-val": code.val,
            "captcha-key": code.key,
        },
        data: {
            phone: form.phone,
            password: form.password
        },

    })

}




function submitLogout() {
    return request({
        method: 'post',
        url: '/logout',
    })

}

function getUserInfo() {
    return request({
        method: 'get',
        url: '/getUserInfo',
    })

}

function updatePass(data) {
    return request({
        method: 'post',
        url: `/updatePass`,
        data
    })
}


function updateUser(data) {
    return request({
        method: 'post',
        url: `/updateUser`,
        data
    })
}


export {
    getCaptcha,
    submitLogin,
    submitLogout,
    getUserInfo,
    updatePass,
    updateUser
}