// 合同管理
var checkMoney = (rule, value, callback) => {
    if (!value) {
        return callback("输入缴纳金额不能为空")
    } else {
        callback()
    }
}


let submitRules = () => {
    return {
        money: [{ validator: checkMoney, trigger: "blur" }],
    }
}

export {
    submitRules
}