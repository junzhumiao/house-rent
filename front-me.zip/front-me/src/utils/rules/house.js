
import { UserConstants } from "@/constants/index"
import UserUtil from "@/utils/user-util"

var checkLinkPhone = (rule, value, callback) => {
    if (!value) {
        return callback("联系人电话不能为空")
    } else if (!UserUtil.verifyPhone(value)) {
        return callback(new Error(UserConstants.PHONE_NOT_MATCH))
    } else {
        callback()
    }
}


var checkLinkMan = (rule, value, callback) => {
    if (!value) {
        return callback("联系人不能为空")
    } else if (!UserUtil.verifyUsername(value)) {
        return callback(new Error("联系人姓名格式不对"))
    } else {
        callback()
    }
}

var checkAddress = (rule, value, callback) => {
    if (!value) {
        return callback("房屋地址不能为空")
    } else {
        callback()
    }
}


var checkPass = (rule, value, callback) => {
    if (!value) {
        return callback("电子锁密码不能为空")
    } else {
        callback()
    }
}


// 用户管理
let submitRules = () => {
    return {
        linkPhone: [{ validator: checkLinkPhone, trigger: "blur" }],
        linkMan: [{ validator: checkLinkMan, trigger: "blur" }],
        address: [{ validator: checkAddress, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
    }
}


export { submitRules }