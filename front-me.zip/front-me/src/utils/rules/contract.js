
import UserUtil from "@/utils/user-util"
var checkHouseId = (rule, value, callback) => {
    if (!value) {
        return callback("房屋编号不能为空")
    } else {
        callback()
    }
}

var checkEarnest = (rule, value, callback) => {
    if (!value) {
        return callback("规定保证金不能为空")
    } else {
        callback()
    }
}

var checkRent = (rule, value, callback) => {
    if (!value) {
        return callback("规定租金不能为空")
    } else {
        callback()
    }
}

var checkTenant = (rule, value, callback) => {
    if (!value) {
        return callback("租客用户地址不能为空")
    } else if (!UserUtil.verifyAccount(value)) {
        return callback("租客地址格式不对")
    } else {
        callback()
    }
}


var checkBeginTime = (rule, value, callback) => {
    if (!value) {
        return callback("合同结束时间不能为空")
    } else {
        callback()
    }
}

// 合同管理
let submitRules = () => {
    return {
        houseId: [{ validator: checkHouseId, trigger: "blur" }]
    }
}

let signRules = () => {
    return {
        rent: [{ validator: checkRent, trigger: "blur" }],
        earnest: [{ validator: checkEarnest, trigger: "blur" }],
        tenant: [{ validator: checkTenant, trigger: "blur" }],
        beginEndTime: [{ validator: checkBeginTime, trigger: "blur" }]
    }

}


export { submitRules, signRules }