
import { UserConstants } from "@/constants/index"
import UserUtil from "@/utils/user-util"


var checkPass = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("密码不能为空"))
    } else if (!UserUtil.verifyPassword(value)) {
        return callback(new Error(UserConstants.PASSWORD_NOT_MATCH))
    } else {
        callback()
    }
}

let checkCode = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("验证码不能为空"))
    }
    else {
        callback()
    }
}

var checkPhone = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("电话不能为空"))
    } else if (!UserUtil.verifyPhone(value)) {
        return callback(new Error(UserConstants.PHONE_NOT_MATCH))
    } else {
        callback()
    }
}

var checkUsername = (rule, value, callback) => {
    if (!value) {
        return callback(new Error('用户名不能为空'))
    } else if (!UserUtil.verifyUsername(value)) {
        return callback(new Error(UserConstants.USERNAME_NOT_MATCH))
    } else {
        callback()
    }
}

var checkUser = (rule, value, callback) => {
    if (!value) {
        return callback("区块链账户地址不能为空")
    } else if (!UserUtil.verifyAccount(value)) {
        return callback(new Error(UserConstants.ACCOUNT_NOT_MATCH))
    } else {
        callback()
    }
}
let checkOldPass = (rule, value, callback) => {
    if (!value) {
        return callback(new Error("旧密码不能为空"))
    }
    if (!UserUtil.verifyPassword(value)) {
        return callback(new Error("旧密码格式不对"))
    } else {
        callback()
    }
}



let loginRules = () => {
    return {
        phone: [{ validator: checkPhone, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
        code: [{ validator: checkCode, trigger: "blur" }],
    }
}

// 用户管理
let submitRules = () => {
    return {
        username: [{ validator: checkUsername, trigger: "blur" }],
        password: [{ validator: checkPass, trigger: "blur" }],
        phone: [{ validator: checkPhone, trigger: "blur" }],
        user: [{ validator: checkUser, trigger: "blur" }]
    }
}


// 个人中心

let baseUserRules = () => {
    return {
        username: [{ validator: checkUsername, trigger: "blur" }],
        phone: [{ validator: checkPhone, trigger: "blur" }],
    }
}


let passRules = () => {
    return {
        oldPass: [{ validator: checkOldPass, trigger: "blur" }],
    }
}



export { loginRules, submitRules, baseUserRules, passRules }