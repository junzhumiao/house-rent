function Uuid(len, radix) {
    var chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'.split('');
    var uuid = [], i;
    radix = radix || chars.length;
    if (len) {
        // Compact form
        for (i = 0; i < len; i++) uuid[i] = chars[0 | Math.random() * radix];
    } else {
        // rfc4122, version 4 form
        var r;
        // rfc4122 requires these characters
        uuid[8] = uuid[13] = uuid[18] = uuid[23] = '-';
        uuid[14] = '4';
        // Fill in random data.  At i==19 set the high bits of clock sequence as
        // per rfc4122, sec. 4.1.5
        for (i = 0; i < 36; i++) {
            if (!uuid[i]) {
                r = 0 | Math.random() * 16;
                uuid[i] = chars[(i == 19) ? (r & 0x3) | 0x8 : r];
            }
        }
    }
    return uuid.join('');
}

function retainTwo(val) {
    let str = val + ''
    if (str.indexOf('.') == -1) {
        str += '.00'
        return str

    }
    // 长度不够截取
    let l = str.indexOf('.') + 3
    let cha = str.length - l
    if (cha >= 0) {
        return str.substring(0, l)
    } else {
        cha = -cha
        for (let i = 0; i < cha; i++) {
            str += '0'
        }
        return str
    }
}


let Tool = {
    uuid(uuid = 32) {
        return Uuid(uuid)
    },
    // 返回保留2位小数的字符串
    retainTwo,
    parseInts(strs) {
        let ints = []
        for (let i = 0; i < strs.length; i++) {
            const str = strs[i];
            try {
                ints.push(parseInt(str))
            } catch (error) {
                console.error(error);
                return []
            }
        }
        return ints
    },
    // 本地存储封装
    setStorage(key, val) {
        if (typeof val == "object") {
            localStorage.setItem(key, JSON.stringify(val))
        } else {
            localStorage.setItem(key, val)
        }
    },
    getStorage(key) {
        let val = localStorage.getItem(key)
        let parseVal = null
        try {
            parseVal = JSON.parse(val) // 不是合法json字符,那么就是字符串
        } catch (error) {
            return val
        }
        if (!val) {
            return null
        }
        else if (typeof parseVal == "object") {
            return parseVal
        } else {
            return val
        }
    },
    removeStorage(key) {
        localStorage.removeItem(key)
    },
    // 注册插件
    usePlugin(org, plugin) {
        for (const key in plugin) {
            org[key] = plugin[key]
        }
    },
    // 查询目标元素在数组
    findEle(val, vals) {
        for (let i = 0; i < vals.length; i++) {
            if (val == vals[i]) {
                return true
            }

        }
        return false
    },
    // 删除对象空值字段
    removeNullFiled(obj) {
        let nObj = { ...obj }
        for (const key in nObj) {
            if (Object.hasOwnProperty.call(nObj, key)) {
                let val = nObj[key]
                if (val == null || val == '') {
                    delete nObj[key] // if null,删除该字段
                }
                if (nObj.length && nObj.length === 0) {
                    delete nObj[key]
                }
            }
        }
        return nObj
    },
    // 省略字符:如: 1、2、3 = 1、2...
    handlerLongStr(str) {
        let res = '';
        let len = str.length
        if (len > 13) {
            res = str.substring(0, 10) + '...'
        } else {
            res = str
        }
        return res
    },
    // 校验列表:待校验列表、校验单个元素函数
    checkList(list, func) {
        for (let i = 0; i < list.length; i++) {
            const item = list[i];
            let end = func(item)
            if (!end) {
                return false
            }
        }
        return true
    },
    // 对象字段全部为空值
    objEmptyStr(obj, ...lose) {
        for (const key in obj) {
            if (!Object.hasOwnProperty.call(obj, key)) {
                continue
            }
            if (lose.indexOf(key) != -1) {
                continue
            }
            let type = typeof obj[key]
            if (type == 'string') {
                obj[key] = ''
            }
            if (type == 'number') {
                obj[key] = 1
            }
        }
    }

}

export default Tool