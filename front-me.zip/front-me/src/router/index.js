import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '@/pages/login'
// 系统内部
import MixHome from '@/pages/MixHome.vue'
import Index from '@/pages/index'
import User from '@/pages/user'
import House from '@/pages/house'
import ContractPre from '@/pages/contract/pre.vue'
import ContractSign from '@/pages/contract/sign.vue'
import ContractBegin from '@/pages/contract/begin.vue'
import ContractStop from '@/pages/contract/stop.vue'
import Payment from '@/pages/payment'
// 个人中心
import UserProfile from '@/pages/user-profile'


Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: '/login'
  },
  {
    path: '/login',
    name: 'login',
    component: Login
  },
  {
    path: '/home',
    component: MixHome,
    children: [
      // 首页
      {
        path: '/index',
        name: 'index',
        component: Index
      },
      {
        path: '/user',
        name: 'user',
        component: User
      },
      {
        path: '/house',
        name: 'house',
        component: House
      },
      {
        path: '/contract/pre',
        name: '/contractPre',
        component: ContractPre
      },
      {
        path: '/contract/sign',
        name: '/contractSign',
        component: ContractSign
      },
      {
        path: '/contract/begin',
        name: '/contractBegin',
        component: ContractBegin
      },
      {
        path: '/contract/stop',
        name: '/contractStop',
        component: ContractStop
      },
      {
        path: '/payment',
        name: '/payment',
        component: Payment
      },
      {
        path: '/user/profile',
        name: '/userProfile',
        component: UserProfile
      },
    ]
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

const originalPush = VueRouter.prototype.push

VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}


export default router
