<template>
<div class="index">
	<div class="login-box">
		<h5 class="title">登录</h5>
		<el-form :model="loginForm" :rules="loginRules" ref="loginForm" label-width="6.25rem" class="login-form">
			<el-form-item prop="phone">
				<el-input clearable prefix-icon="el-icon-mobile-phone" v-model="loginForm.phone"
					placeholder="电话"></el-input>
			</el-form-item>
			<el-form-item prop="password">
				<el-input show-password clearable prefix-icon="el-icon-lock" v-model="loginForm.password"
					placeholder="密码"></el-input>
			</el-form-item>
			<el-form-item prop="role" style="width: 190px">
				<el-select v-model="loginForm.role" clearable placeholder="角色">
					<el-option v-for="item in roleOptions" :key="item.value" :label="item.label" :value="item.value">
					</el-option>
				</el-select>
			</el-form-item>
			<el-form-item prop="code" style="width: 190px">
				<el-input clearable prefix-icon="el-icon-key" v-model="loginForm.code" placeholder="验证码"
					maxlength="6"></el-input>
				<div class="code-box" @click="getCaptcha">
					<img :src="code.url" />
				</div>
			</el-form-item>
			<el-form-item>
				<el-button style="width: 100%" type="primary" @click="login('loginForm')" :loading="loadLogin">{{
					loadLogin ? "" : "登录" }}</el-button>
			</el-form-item>
		</el-form>
	</div>
</div>
</template>

<script>
import { getCaptcha, submitLogin } from "@/api/login"
import { loginRules } from "@/utils/rules/user"
import { roleOptions } from "@/constants/user"
export default {
	name: "FrontLogin",

	data() {
		return {
			roleOptions,
			loadLogin: false,
			loginForm: {
				phone: "15069680202",
				password: "123456",
				role: "1",
				code: "",
			},
			code: {
				key: "",
				url: "",
			},
		}
	},
	computed: {
		loginRules,
	},
	mounted() {
		// 关闭之前没关闭的弹窗
		if (this.loadInstance()) {
			this.closeLoading()
		}
		this.getCaptcha()
	},
	methods: {
		async login(formName) {
			// 校验成功,提交表单
			if (this.checkForm(this, formName)) {
				let post = {
					code: {
						...this.code,
						val: this.loginForm.code,
					},
					form: this.loginForm,
				}
				this.loadLogin = true
				let res = await submitLogin(post)
				if (res.code == 200) {
					this.$store.commit("login", res.data)
					this.$router.push("/index")
				}
				this.loadLogin = false
			}
		},
		async getCaptcha() {
			try {
				let res = await getCaptcha()
				if (res.code == 200) {
					let { codeUrl, codeKey } = res.data
					this.code.url = codeUrl
					this.code.key = codeKey
				}
			} catch (error) {
				console.error(error)
			}
		},
	},
}
</script>

<style lang="scss" scoped>
// 深度穿透样式
::v-deep .el-form-item__content {
	margin: 0 !important;
}

.index {
	display: flex;
	justify-content: center;
	align-items: center;
	height: 100%;
	width: 100%;
	background-image: url("@/static/imgs/login/bg.gif");
}

.login-box {
	width: 22.5rem;
	height: 25rem;
	background: white;

	.title,
	.login-form {
		margin: 20px 0 0 0;
	}

	.title {
		height: 20px;
		line-height: 20px;
		font-size: 18px;
		text-align: center;
	}

	.login-form {
		width: 320px;
		// height: 380px;
		padding: 20px;

		.code-box {
			right: -120px;
			position: absolute;
			bottom: -1px;
			width: 100px;
			height: 40px;
			border: 1px solid rgba(23, 201, 103, 0.725);

			img {
				width: 100%;
				height: 100%;
			}
		}
	}
}
</style>
