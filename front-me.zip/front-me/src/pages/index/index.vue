<template>
	<div class="index">
		<el-row>
			<el-col :span="12">
				<el-timeline :reverse="reverse" style="height: 600px">
					<el-steps :active="3" align-center direction="vertical">
						<el-step
							:title="item.roleName"
							:description="item.content"
							v-for="item in list"
							:key="item.roleName"
						></el-step>
					</el-steps>
				</el-timeline>
			</el-col>
			<el-col :span="12">
				<el-descriptions title="具体角色介绍" border :column="1">
					<el-descriptions-item label="管理员"
						>具体能干的事负责能管理员用户
					</el-descriptions-item>
					<el-descriptions-item label="房东"
						>负责发布合同、添加房屋之类的、关于房东预存押金方面(超过签署过期时间,租客预存钱会退到租客账户里)、
						关于房东终止合同方面(终止合同,会赔偿保证金给对方,并且租客多缴纳的租金退还给房东)
					</el-descriptions-item>
					<el-descriptions-item label="租客">
						关于租客终止合同方面(终止合同,会赔偿保证金和1个月的租金、如果1个月的保证金没了,会扣除2个月的租金，其余租客多缴纳的租金返还)
					</el-descriptions-item>
				</el-descriptions>
			</el-col>
		</el-row>
	</div>
</template>

<script>
export default {
	name: "FrontMeIndex",

	data() {
		return {
			list: [
				{ roleName: "管理员", content: "添加、修改用户,修改用户密码、用户重置" },
				{ roleName: "房东", content: "添加房屋、添加预发布合同、终止合同" },
				{ roleName: "租客", content: "签署合同、终止合同" },
			],
		}
	},

	mounted() {},

	methods: {},
}
</script>

<style lang="scss" scoped></style>
