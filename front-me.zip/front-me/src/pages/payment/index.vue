<template>
	<div class="payment">
		<!-- 搜索 -->
		<el-row class="searchForm" v-if="showSearch">
			<el-col>
				<el-form
					ref="searchForm"
					:model="searchForm"
					status-icon
					label-width="100px"
					size="mini"
					:inline="true"
				>
					<el-form-item label="缴纳人账户地址" prop="payer" class="form-item">
						<el-input
							v-model.trim="searchForm.payer"
							placeholder="请输入缴纳人账户地址"
							class="form-input"
						></el-input>
					</el-form-item>
					<el-form-item label="合同序列号" prop="contractNum" class="form-item">
						<el-input
							v-model.trim="searchForm.contractNum"
							placeholder="请输入合同序列号"
							class="form-input"
						></el-input>
					</el-form-item>
				</el-form>
			</el-col>
		</el-row>
		<!-- 搜素重置按钮 -->
		<el-row class="row-item">
			<el-col :push="1" :span="23">
				<el-button type="primary" size="mini" icon="el-icon-search" @click="search"
					>搜索</el-button
				>
				<el-button
					size="mini"
					icon="el-icon-refresh"
					@click="resetForm('searchForm')"
					v-if="showSearch"
					>重置
				</el-button>
			</el-col>
		</el-row>
		<!-- 增删改表单按钮 -->
		<el-row class="row-item">
			<!-- 右侧 -->
			<el-col :push="1" :span="2">
				<el-tooltip effect="dark" content="隐藏搜索" placement="top">
					<el-button
						size="mini"
						circle
						icon="el-icon-search"
						@click="showSearch = !showSearch"
					>
					</el-button>
				</el-tooltip>
				<el-tooltip effect="dark" content="刷新" placement="top">
					<el-button size="mini" circle icon="el-icon-refresh" @click="refresh">
					</el-button>
				</el-tooltip>
				<el-tooltip effect="dark" content="隐藏列" placement="top">
					<el-button
						size="mini"
						circle
						icon="el-icon-menu"
						@click="showHidCol = !showHidCol"
					>
					</el-button>
				</el-tooltip>
				<el-popover width="60" placement="bottom" trigger="click" v-model="showHidCol">
					<el-checkbox-group v-model="checkedColumns">
						<el-checkbox v-for="column in columns" :label="column" :key="column">
						</el-checkbox>
					</el-checkbox-group>
				</el-popover>
			</el-col>
		</el-row>
		<!-- 表格 -->
		<el-row>
			<el-table
				ref="multipleTable"
				:data="list"
				tooltip-effect="dark"
				style="width: 100%"
				@selection-change="handMulSelect"
			>
				<el-table-column
					prop="paymentId"
					label="缴纳记录编号"
					v-if="$Tool.findEle('缴纳记录编号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="payer"
					label="缴纳人账户地址"
					v-if="$Tool.findEle('缴纳人账户地址', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="money"
					label="缴纳金额"
					v-if="$Tool.findEle('缴纳金额', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="contractNum"
					label="合同序列码"
					v-if="$Tool.findEle('合同序列码', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="createTime"
					label="创建时间"
					v-if="$Tool.findEle('创建时间', checkedColumns)"
				>
				</el-table-column>
			</el-table>
		</el-row>
		<!-- 分页 -->
		<el-row type="flex" justify="center" style="padding-top: 20px">
			<el-col :span="6">
				<el-pagination
					background
					@size-change="handlePageSize"
					@current-change="handlePage"
					:current-page="searchForm.page"
					:page-sizes="[10, 20, 30, 40]"
					:page-size="searchForm.pageSize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="listTotal"
				>
				</el-pagination>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import { getAllPayment } from "@/api/payment"
import { columns } from "@/constants/payment"
export default {
	name: "FrontPayment",
	data() {
		return {
			// 表单dialog
			showDialog: false,
			dialogTitle: "",
			// 隐藏，显示列
			checkedColumns: columns,
			columns: columns,
			showHidCol: false,
			showSearch: true,
			searchForm: {
				payer: "",
				contractNum: "",
				page: 1,
				pageSize: 10,
			},
			list: [],
			listTotal: 0,
			//选中的主键
			checkIds: [],
			checkedItems: [],
		}
	},

	mounted() {
		this.get()
	},

	methods: {
		search() {
			this.get()
		},
		async get() {
			let search = { ...this.searchForm }
			let res = await getAllPayment(this.$Tool.removeNullFiled(search))
			if (res.code == 200) {
				this.list = res.data
				this.listTotal = res.total
			}
		},
		refresh() {
			this.get()
		},
		resetForm(formName) {
			this.$Tool.objEmptyStr(this[formName], "page", "pageSize")
			this.$refs[formName].resetFields()
		},
		// 处理多选
		handMulSelect(list) {
			this.checkIds = list.map((item) => item.paymentId)
			this.checkedItems = list
		},
		handlePageSize(val) {
			this.searchForm.pageSize = val
			this.refresh()
		},
		handlePage(val) {
			this.searchForm.page = val
			this.refresh()
		},
	},
}
</script>

<style lang="scss" scoped></style>
