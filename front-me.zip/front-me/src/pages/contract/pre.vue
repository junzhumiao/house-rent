<template>
	<div class="contract">
		<!-- 增删改表单按钮 -->
		<el-row class="row-item">
			<!-- 左侧 -->
			<el-col :push="1" :span="20">
				<el-button plain type="primary" size="mini" icon="el-icon-plus" @click="create"
					>新增
				</el-button>
			</el-col>
			<!-- 右侧 -->
			<el-col :push="1" :span="2">
				<el-tooltip effect="dark" content="刷新" placement="top">
					<el-button size="mini" circle icon="el-icon-refresh" @click="refresh">
					</el-button>
				</el-tooltip>
				<el-tooltip effect="dark" content="隐藏列" placement="top">
					<el-button
						size="mini"
						circle
						icon="el-icon-menu"
						@click="showHidCol = !showHidCol"
					>
					</el-button>
				</el-tooltip>
				<el-popover width="60" placement="bottom" trigger="click" v-model="showHidCol">
					<el-checkbox-group v-model="checkedColumns">
						<el-checkbox v-for="column in columns" :label="column" :key="column">
						</el-checkbox>
					</el-checkbox-group>
				</el-popover>
			</el-col>
		</el-row>
		<!-- 表格 -->
		<el-row>
			<el-table
				ref="multipleTable"
				:data="list"
				tooltip-effect="dark"
				style="width: 100%"
				@selection-change="handMulSelect"
			>
				<el-table-column
					prop="contractId"
					label="合同编号"
					v-if="$Tool.findEle('合同编号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="houseId"
					label="房屋编号"
					v-if="$Tool.findEle('房屋编号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="landlordId"
					label="房东编号"
					v-if="$Tool.findEle('房东编号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="contractNum"
					label="合同序列码"
					v-if="$Tool.findEle('合同序列码', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="createTime"
					label="创建时间"
					v-if="$Tool.findEle('创建时间', checkedColumns)"
				>
				</el-table-column>
				<el-table-column label="操作">
					<template slot-scope="scope">
						<el-row>
							<el-button
								@click.native.prevent="sign(scope.row)"
								type="text"
								icon="el-icon-scissors"
								size="small"
							>
								签署
							</el-button>
						</el-row>
					</template>
				</el-table-column>
			</el-table>
		</el-row>
		<!-- 分页 -->
		<el-row type="flex" justify="center" style="padding-top: 20px">
			<el-col :span="6">
				<el-pagination
					background
					@size-change="handlePageSize"
					@current-change="handlePage"
					:current-page="searchForm.page"
					:page-sizes="[10, 20, 30, 40]"
					:page-size="searchForm.pageSize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="listTotal"
				>
				</el-pagination>
			</el-col>
		</el-row>
		<!-- 修改,添加dialog -->
		<el-dialog
			:title="dialogTitle"
			:visible.sync="showDialog"
			:before-close="closeDialog"
			width="45%"
		>
			<el-form
				:model="submitForm"
				:rules="submitRules"
				ref="submitForm"
				label-width="6.25rem"
				inline
				class="submit-form"
			>
				<el-form-item label="房屋编号" prop="houseId" required class="form-item">
					<el-input
						clearable
						v-model="submitForm.houseId"
						placeholder="请输入房屋编号"
					></el-input>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="closeDialog">取 消</el-button>
				<el-button type="primary" @click="submit(dialogTitle)">确 定</el-button>
			</div>
		</el-dialog>
		<!-- 签署弹窗 -->
		<el-dialog
			title="签署合同"
			:visible.sync="showSignDialog"
			:before-close="closeSignDialog"
			width="45%"
		>
			<el-form
				:model="signForm"
				:rules="signRules"
				ref="signForm"
				label-width="6.25rem"
				inline
				class="submit-form"
			>
				<el-form-item label="租客地址" prop="tenant" required class="form-item">
					<el-input
						clearable
						v-model="signForm.tenant"
						placeholder="请输入租客地址"
					></el-input>
				</el-form-item>
				<el-form-item label="规定保证金" prop="earnest" required class="form-item">
					<el-input
						clearable
						v-model="signForm.earnest"
						placeholder="请输入保证金"
					></el-input>
				</el-form-item>
				<el-form-item label="规定租金" prop="rent" required class="form-item">
					<el-input clearable v-model="signForm.rent" placeholder="请输入租金"></el-input>
				</el-form-item>
				<el-form-item
					label="合同生效结束时间"
					prop="beginEndTime"
					required
					class="form-item"
				>
					<el-date-picker
						v-model="signForm.beginEndTime"
						type="datetime"
						placeholder="请输入合同生效结束时间"
						value-format="yyyy-MM-dd HH:mm:ss"
					>
					</el-date-picker>
				</el-form-item>
			</el-form>
			<div slot="footer" class="dialog-footer">
				<el-button @click="closeSignDialog">取 消</el-button>
				<el-button type="primary" @click="submitSign">确 定</el-button>
			</div>
		</el-dialog>
	</div>
</template>

<script>
import { submitRules, signRules } from "@/utils/rules/contract"
import { getAllContract, createContract, signContract } from "@/api/contract"
import { preColumns, Type } from "@/constants/contract"
export default {
	name: "FrontContract",
	data() {
		return {
			// 表单dialog
			showSignDialog: false,
			showDialog: false,
			dialogTitle: "",
			// 隐藏，显示列
			checkedColumns: preColumns,
			columns: preColumns,
			showHidCol: false,
			searchForm: {
				type: Type.Pre,
				page: 1,
				pageSize: 10,
			},
			list: [],
			listTotal: 0,
			//选中的主键
			checkIds: [],
			checkedItems: [],
			// 提交表单
			submitForm: {
				houseId: "",
			},
			signForm: {
				tenant: "",
				rent: "",
				earnest: "",
				beginEndTime: "",
				contractId: "",
				landlordId: "",
			},
			submitFormCopy: {},
		}
	},
	computed: {
		submitRules,
		signRules,
	},

	mounted() {
		this.get()
		this.submitFormCopy = { ...this.submitForm }
	},

	methods: {
		create() {
			this.openDialog("新增合同")
		},
		async get() {
			let search = { ...this.searchForm }
			let res = await getAllContract(this.$Tool.removeNullFiled(search))
			if (res.code == 200) {
				this.list = res.data
				this.listTotal = res.total
			}
		},
		sign({ contractId, landlordId }) {
			this.signForm.contractId = contractId
			this.signForm.landlordId = landlordId
			this.openSignDialog()
		},
		async submitSign() {
			if (this.checkForm(this, "signForm")) {
				let submit = { ...this.signForm }
				let res = await signContract(submit)
				if (res.code == 200) {
					this.closeSignDialog()
					this.refresh()
				}
			}
		},
		openSignDialog() {
			this.showSignDialog = true
		},
		closeSignDialog() {
			this.resetForm("signForm")
			this.showSignDialog = false
		},
		// 打开表单弹窗
		openDialog(title) {
			this.showDialog = true
			this.dialogTitle = title
		},
		// 关闭表单弹窗,清除表单
		closeDialog() {
			this.resetForm("submitForm")
			this.submitForm = { ...this.submitFormCopy }
			this.showDialog = false
			this.dialogTitle = ""
		},
		// 提交表单
		async submit(title) {
			if (this.checkForm(this, "submitForm")) {
				if (title == "新增合同") {
					this.submitCreate(title)
				}
			}
		},
		async submitCreate(title) {
			let res = await createContract(this.submitForm)
			if (res.code == 200) {
				this.refresh()
				this.closeDialog()
			} else {
				this.openDialog(title)
			}
		},
		refresh() {
			this.get()
		},
		resetForm(formName) {
			this.$Tool.objEmptyStr(this[formName], "page", "pageSize")
			this.$refs[formName].resetFields()
		},
		// 处理多选
		handMulSelect(list) {
			this.checkIds = list.map((item) => item.contractId)
			this.checkedItems = list
		},
		handlePageSize(val) {
			this.searchForm.pageSize = val
			this.refresh()
		},
		handlePage(val) {
			this.searchForm.page = val
			this.refresh()
		},
		// 封装本组件弹窗
		handConfirm(text, data, success, error = () => {}) {
			this.confirm(
				this.$confirm,
				`您是否确认${text}合同编号为"${this.$Tool.handlerLongStr(
					data.toString()
				)}"的数据项`,
				success,
				error
			)
		},
	},
}
</script>

<style lang="scss" scoped></style>
