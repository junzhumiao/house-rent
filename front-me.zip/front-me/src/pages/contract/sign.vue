<template>
	<div class="contract">
		<!-- 增删改表单按钮 -->
		<el-row class="row-item">
			<!-- 右侧 -->
			<el-col :push="1" :span="2">
				<el-tooltip effect="dark" content="刷新" placement="top">
					<el-button size="mini" circle icon="el-icon-refresh" @click="refresh">
					</el-button>
				</el-tooltip>
				<el-tooltip effect="dark" content="隐藏列" placement="top">
					<el-button
						size="mini"
						circle
						icon="el-icon-menu"
						@click="showHidCol = !showHidCol"
					>
					</el-button>
				</el-tooltip>
				<el-popover width="60" placement="bottom" trigger="click" v-model="showHidCol">
					<el-checkbox-group v-model="checkedColumns">
						<el-checkbox v-for="column in columns" :label="column" :key="column">
						</el-checkbox>
					</el-checkbox-group>
				</el-popover>
			</el-col>
		</el-row>
		<!-- 表格 -->
		<el-row>
			<el-table
				ref="multipleTable"
				:data="list"
				tooltip-effect="dark"
				style="width: 100%"
				@selection-change="handMulSelect"
			>
				<el-table-column
					prop="contractId"
					label="合同编号"
					v-if="$Tool.findEle('合同编号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="signTime"
					label="签署时间"
					v-if="$Tool.findEle('签署时间', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="signEndTime"
					label="签署结束时间"
					v-if="$Tool.findEle('签署结束时间', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="isTenEarnest"
					label="租客预存保证金"
					v-if="$Tool.findEle('租客预存保证金', checkedColumns)"
				>
					<template slot-scope="scope">
						{{ judgeMap[scope.row.isTenEarnest] }}
					</template>
				</el-table-column>
				<el-table-column
					prop="isLanEarnest"
					label="房东预存保证金"
					v-if="$Tool.findEle('房东预存保证金', checkedColumns)"
				>
					<template slot-scope="scope">
						{{ judgeMap[scope.row.isLanEarnest] }}
					</template>
				</el-table-column>
				<el-table-column
					prop="isTenRent"
					label="租客预存租金"
					v-if="$Tool.findEle('租客预存租金', checkedColumns)"
				>
					<template slot-scope="scope">
						{{ judgeMap[scope.row.isTenRent] }}
					</template>
				</el-table-column>
				<el-table-column
					prop="tenant"
					label="租客地址"
					v-if="$Tool.findEle('租客地址', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="landlord"
					label="房东地址"
					v-if="$Tool.findEle('房东地址', checkedColumns)"
				>
				</el-table-column>
				<el-table-column label="操作">
					<template slot-scope="scope">
						<el-row type="flex">
							<el-button
								@click.native.prevent="tenantPrestore(scope.row)"
								type="success"
								size="small"
							>
								租客预存
							</el-button>
							<el-button
								@click.native.prevent="landlordPrestore(scope.row)"
								type="primary"
								size="small"
							>
								房东预存
							</el-button>
						</el-row>
					</template>
				</el-table-column>
			</el-table>
		</el-row>
		<!-- 分页 -->
		<el-row type="flex" justify="center" style="padding-top: 20px">
			<el-col :span="6">
				<el-pagination
					background
					@size-change="handlePageSize"
					@current-change="handlePage"
					:current-page="searchForm.page"
					:page-sizes="[10, 20, 30, 40]"
					:page-size="searchForm.pageSize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="listTotal"
				>
				</el-pagination>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import { getAllContract, tenantPrestore, landlordPrestore } from "@/api/contract"
import { signColumns, Type } from "@/constants/contract"
import { judgeMap } from "@/constants/index.js"
export default {
	name: "FrontContract",
	data() {
		return {
			// 隐藏，显示列
			checkedColumns: signColumns,
			columns: signColumns,
			showHidCol: false,
			judgeMap,
			searchForm: {
				type: Type.Sign,
				page: 1,
				pageSize: 10,
			},
			list: [],
			listTotal: 0,
		}
	},

	mounted() {
		this.get()
	},

	methods: {
		async get() {
			let search = { ...this.searchForm }
			let res = await getAllContract(this.$Tool.removeNullFiled(search))
			if (res.code == 200) {
				this.list = res.data
				this.listTotal = res.total
			}
		},
		tenantPrestore({ contractId }) {
			this.handConfirm("预存保证金、租金", contractId, () =>
				this.submitTenantPrestore(contractId)
			)
		},
		async submitTenantPrestore(contractId) {
			let res = await tenantPrestore({ contractId })
			if (res.code == 200) {
				this.refresh()
				this.$message.success("租客预存押金成功")
			}
		},
		landlordPrestore({ contractId }) {
			this.handConfirm("预存押金", contractId, () => this.submitLandlordPrestore(contractId))
		},
		async submitLandlordPrestore(contractId) {
			let res = await landlordPrestore({ contractId })
			if (res.code == 200) {
				this.refresh()
				this.$message.success("房东预存押金成功")
			}
		},
		refresh() {
			this.get()
		},
		resetForm(formName) {
			this.$Tool.objEmptyStr(this[formName], "page", "pageSize")
			this.$refs[formName].resetFields()
		},
		// 处理多选
		handMulSelect(list) {
			this.checkIds = list.map((item) => item.contractId)
			this.checkedItems = list
		},
		handlePageSize(val) {
			this.searchForm.pageSize = val
			this.refresh()
		},
		handlePage(val) {
			this.searchForm.page = val
			this.refresh()
		},
		// 封装本组件弹窗
		handConfirm(text, data, success, error = () => {}) {
			this.confirm(
				this.$confirm,
				`您是否确认${text}合同编号为"${this.$Tool.handlerLongStr(
					data.toString()
				)}"的数据项`,
				success,
				error
			)
		},
	},
}
</script>

<style lang="scss" scoped></style>
