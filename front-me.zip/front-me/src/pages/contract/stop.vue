<template>
	<div class="contract">
		<!-- 增删改表单按钮 -->
		<el-row class="row-item">
			<!-- 右侧 -->
			<el-col :push="1" :span="20">
				<el-tooltip effect="dark" content="刷新" placement="top">
					<el-button size="mini" circle icon="el-icon-refresh" @click="refresh">
					</el-button>
				</el-tooltip>
				<el-tooltip effect="dark" content="隐藏列" placement="top">
					<el-button
						size="mini"
						circle
						icon="el-icon-menu"
						@click="showHidCol = !showHidCol"
					>
					</el-button>
				</el-tooltip>
				<el-popover width="60" placement="bottom" trigger="click" v-model="showHidCol">
					<el-checkbox-group v-model="checkedColumns">
						<el-checkbox v-for="column in columns" :label="column" :key="column">
						</el-checkbox>
					</el-checkbox-group>
				</el-popover>
			</el-col>
		</el-row>
		<!-- 表格 -->
		<el-row>
			<el-table
				ref="multipleTable"
				:data="list"
				tooltip-effect="dark"
				style="width: 100%"
				@selection-change="handMulSelect"
			>
				<el-table-column
					prop="contractId"
					label="合同编号"
					v-if="$Tool.findEle('合同编号', checkedColumns)"
				>
				</el-table-column>

				<el-table-column
					prop="contractNum"
					label="合同序列号"
					v-if="$Tool.findEle('合同序列号', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="stopTime"
					label="合同终止时间"
					v-if="$Tool.findEle('合同终止时间', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="tenant"
					label="租客地址"
					v-if="$Tool.findEle('租客地址', checkedColumns)"
				>
				</el-table-column>
				<el-table-column
					prop="landlord"
					label="房东地址"
					v-if="$Tool.findEle('房东地址', checkedColumns)"
				>
				</el-table-column>
			</el-table>
		</el-row>
		<!-- 分页 -->
		<el-row type="flex" justify="center" style="padding-top: 20px">
			<el-col :span="6">
				<el-pagination
					background
					@size-change="handlePageSize"
					@current-change="handlePage"
					:current-page="searchForm.page"
					:page-sizes="[10, 20, 30, 40]"
					:page-size="searchForm.pageSize"
					layout="total, sizes, prev, pager, next, jumper"
					:total="listTotal"
				>
				</el-pagination>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import { getAllContract } from "@/api/contract"
import { stopColumns, Type } from "@/constants/contract"
export default {
	name: "FrontContract",
	data() {
		return {
			dialogTitle: "",
			// 隐藏，显示列
			checkedColumns: stopColumns,
			columns: stopColumns,
			showHidCol: false,
			searchForm: {
				type: Type.Stop,
				page: 1,
				pageSize: 10,
			},
			list: [],
			listTotal: 0,
			//选中的主键
			checkIds: [],
			checkedItems: [],
		}
	},

	mounted() {
		this.get()
	},

	methods: {
		async get() {
			let search = { ...this.searchForm }
			let res = await getAllContract(this.$Tool.removeNullFiled(search))
			if (res.code == 200) {
				this.list = res.data
				this.listTotal = res.total
			}
		},
		stop({ contractId }) {
			this.handConfirm("停止", contractId, this.submitStop)
		},
		async submitStop({ contractId }) {
			let res = await stopContract({ contractId })
			if (res.code == 200) {
				this.refresh()
			}
		},
		refresh() {
			this.get()
		},
		resetForm(formName) {
			this.$Tool.objEmptyStr(this[formName], "page", "pageSize")
			this.$refs[formName].resetFields()
		},
		// 处理多选
		handMulSelect(list) {
			this.checkIds = list.map((item) => item.contractId)
			this.checkedItems = list
		},
		handlePageSize(val) {
			this.searchForm.pageSize = val
			this.refresh()
		},
		handlePage(val) {
			this.searchForm.page = val
			this.refresh()
		},
		// 封装本组件弹窗
		handConfirm(text, data, success, error = () => {}) {
			this.confirm(
				this.$confirm,
				`您是否确认${text}合同编号为"${this.$Tool.handlerLongStr(
					data.toString()
				)}"的数据项`,
				success,
				error
			)
		},
	},
}
</script>

<style lang="scss" scoped></style>
