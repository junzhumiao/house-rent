<template>
	<div class="user-profile">
		<el-row>
			<el-col :span="6">
				<!-- 个人信息展示页 -->
				<el-card shadow="always">
					<div slot="header" class="clearfix title">
						<span>个人信息</span>
					</div>
					<el-descriptions :column="1" border>
						<el-descriptions-item label="用户名称">{{
							showUser.username
						}}</el-descriptions-item>
						<el-descriptions-item label="用户角色">{{
							showUser.roleName
						}}</el-descriptions-item>
						<el-descriptions-item label="账户余额">{{
							showUser.balance
						}}</el-descriptions-item>
						<el-descriptions-item label="手机号码">{{
							showUser.phone
						}}</el-descriptions-item>
						<el-descriptions-item label="账户地址">{{
							showUser.user
						}}</el-descriptions-item>
						<el-descriptions-item label="创建日期">
							{{ showUser.createTime }}
						</el-descriptions-item>
					</el-descriptions>
				</el-card>
			</el-col>

			<el-col :span="17" style="margin: 0 0 0 20px; font-weight: 700"
				><el-card shadow="always">
					<div slot="header" class="clearfix title">
						<span>{{ activeTab }}</span>
					</div>
					<el-tabs v-model="activeTab">
						<!-- 基本资料 -->
						<el-tab-pane label="基本资料" name="基本资料">
							<el-form
								ref="baseUserForm"
								label-position="left"
								label-width="80px"
								:model="baseUserForm"
								:rules="baseUserRules"
							>
								<el-form-item label="用户名称" prop="username" required>
									<el-input v-model="baseUserForm.username"></el-input>
								</el-form-item>
								<el-form-item label="手机号码" prop="phone" required>
									<el-input v-model="baseUserForm.phone"></el-input>
								</el-form-item>
								<el-form-item label="性别" prop="sex">
									<el-radio-group v-model="baseUserForm.sex">
										<el-radio label="0">{{ sexMap["0"] }}</el-radio>
										<el-radio label="1">{{ sexMap["1"] }}</el-radio>
									</el-radio-group>
								</el-form-item>
								<el-form-item>
									<el-button type="primary" @click="submitBaseUserForm"
										>保存</el-button
									>
									<el-button type="danger" @click="closeUserProfile"
										>关闭</el-button
									>
								</el-form-item>
							</el-form>
						</el-tab-pane>
						<!-- 修改密码 -->
						<el-tab-pane label="修改密码" name="修改密码">
							<el-form
								ref="passForm"
								label-position="left"
								label-width="80px"
								:model="passForm"
								:rules="passRules"
							>
								<el-form-item label="旧密码" prop="oldPass" required>
									<el-input v-model="passForm.oldPass"></el-input>
								</el-form-item>
								<el-form-item label="新密码" prop="newPass" required>
									<el-input v-model="passForm.newPass"></el-input>
								</el-form-item>
								<el-form-item label="确认密码" prop="confirmPass" required>
									<el-input v-model="passForm.confirmPass"></el-input>
								</el-form-item>
								<el-form-item>
									<el-button type="primary" @click="submitPassForm"
										>保存</el-button
									>
									<el-button type="danger" @click="closeUserProfile"
										>关闭</el-button
									>
								</el-form-item>
							</el-form>
						</el-tab-pane>
					</el-tabs>
				</el-card>
			</el-col>
		</el-row>
	</div>
</template>

<script>
import { TagCurMenu } from "@/utils/index.js"
import { baseUserRules, passRules } from "@/utils/rules/user"
import UserUtil from "@/utils/user-util"
import { updatePass, updateUser } from "@/api/login"
import { sexMap } from "@/constants/user"
export default {
	name: "FrontUserProfile",
	data() {
		return {
			type: "",
			activeTab: "基本资料",
			sexMap,
			showUser: {
				username: "",
				password: "",
				roleName: "",
				phone: "",
				createTime: "",
				sex: "",
				user: "",
				balance: "",
			},
			baseUserForm: {
				phone: "",
				username: "",
				sex: "0",
			},
			passForm: {
				oldPass: "",
				newPass: "",
				confirmPass: "",
			},
		}
	},
	computed: {
		baseUserRules,
		passRules() {
			let checkNewPass = (rule, value, callback) => {
				if (!value) {
					return callback(new Error("新密码不能为空"))
				} else if (!UserUtil.verifyPassword(value)) {
					return callback(new Error("新密码格式不对"))
				} else if (value == this.passForm.oldPass) {
					return callback(new Error("新密码和旧密码不能一致"))
				} else {
					callback()
				}
			}

			// 确认密码对照新密码
			let checkConfirmPass = (rule, value, callback) => {
				if (!value) {
					return callback(new Error("确认密码不能为空"))
				} else if (value != this.passForm.newPass) {
					return callback(new Error("两次输入的密码不一致"))
				} else {
					callback()
				}
			}

			return {
				confirmPass: [{ validator: checkConfirmPass, trigger: "blur" }],
				newPass: [{ validator: checkNewPass, trigger: "blur" }],
				...passRules(),
			}
		},
	},
	mounted() {
		this.get()
	},
	methods: {
		async get() {
			let user = this.$store.state.user
			if (!user) {
				let res = await getUserInfo()
				if (res.code == 200 && res.data) {
					user = res.data.user
				}
			}
			this.showUser = { ...user }
			this.baseUserForm = { ...user }
		},
		// 关闭用户中心页面(跳转到首页)
		closeUserProfile() {
			this.deleteTagAndUpdateCurMenu(this, { path: "/user/profile", label: "个人中心" })
		},

		async submitPassForm() {
			if (this.checkForm(this, "passForm")) {
				let passTo = {
					oldPassword: this.passForm.oldPass,
					newPassword: this.passForm.newPass,
				}
				let res = await updatePass(passTo)
				if (res.code == 200) {
					this.sucMes(this, "用户修改密码成功!")
					this.get()
				}
			}
		},
		// 提交用户信息
		async submitBaseUserForm() {
			if (this.checkForm(this, "baseUserForm")) {
				let res = await updateUser(this.baseUserForm)
				if (res.code == 200) {
					this.sucMes(this, "用户修改信息成功!")
					this.get()
				}
			}
		},
		handlerObjConvertAry: TagCurMenu.handlerObjConvertAry,
		deleteTagAndUpdateCurMenu: TagCurMenu.deleteTagAndUpdateCurMenu,
	},
}
</script>

<style scoped>
.title {
	text-align: start;
	font-weight: bolder;
}
.avatar-box {
	position: relative;
	width: 130px;
	height: 130px;
	margin: 0 auto 20px;
}
.avatar {
	position: absolute;
	top: 0;
	left: 0;
}
.shape {
	position: absolute;
	top: 0;
	left: 0;
	right: 0;
	bottom: 0;
	border-radius: 50%;
	font-size: 60px;
	color: white;
	text-align: center;
	line-height: 130px;
	background: rgb(0, 0, 0, 0.3);
	opacity: 0;
}
.shape:hover {
	opacity: 1;
	cursor: pointer;
}
</style>
