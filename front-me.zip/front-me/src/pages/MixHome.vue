<template>
	<div class="home" style="display: flex; height: 100vh">
		<Aside
			:is-collapse="isCollapse"
			:routers="routers"
			:menu-title="menuTitle"
			:background-color="backgroundColor"
			@click-menu="clickMenu"
		></Aside>
		<div style="flex: auto">
			<Header
				style="height: 50px"
				@click-collapse="clickMenuCollapse"
				@logout="logout"
			></Header>
			<Main></Main>
		</div>
	</div>
</template>

<script>
import Main from "@/components/home/Main.vue"
import Header from "@/components/home/Header.vue"
import Aside from "@/components/home/Aside.vue"
import { TagCurMenu } from "@/utils/index.js"
import { mapState } from "vuex"
import { submitLogout, getUserInfo } from "@/api/login"
import { adminMenus, tenantMenus, landlordMenus } from "@/constants/user"
export default {
	name: "FrontAdminHome",
	components: {
		Aside,
		Header,
		Main,
	},
	data() {
		return {
			menuTitle: {
				label: "房屋转租系统",
				imgUrl: require("@/static/imgs/home/logo.png"),
			},
			isCollapse: false,
			color: "#ffffff",
		}
	},
	computed: {
		...mapState({
			roleId: (state) => (state.user ? state.user.roleId : 1),
			backgroundColor: (state) => state.globalSet.naviColor,
		}),
		routers() {
			return this.showMenus(this.roleId)
		},
	},
	mounted() {
		this.checkLoginUserStatus()
	},
	created() {
		this.getLoginUser()
	},

	methods: {
		showMenus(roleId) {
			if (roleId == 1) {
				return adminMenus
			}
			if (roleId == 2) {
				return landlordMenus
			}
			if (roleId == 3) {
				return tenantMenus
			}
		},
		async getLoginUser() {
			let user = this.$store.state.user
			if (!user) {
				let res = await getUserInfo()
				if (res.code == 200) {
					this.$store.commit("changeUser", res.data)
				}
			}
		},
		checkLoginUserStatus() {
			let token = this.$store.state.token
			if (!token) {
				this.$message.error("用户登录过期或会话状态失效")
				setTimeout(() => {
					this.$router.push("/login")
				}, 1000)
			}
		},
		clickMenuCollapse(val) {
			this.isCollapse = val
		},
		clickMenu(item) {
			this.updateTagCurMenu(this, item)
		},
		logout(val) {
			if (val) {
				this.confirm(this.$confirm, "您是否确认退出账户?", async () => {
					let res = await submitLogout()
					if (res.code == 200) {
						this.$Tool.removeStorage("token")
						this.$router.push("/login")
					}
				})
			}
		},
		updateTagCurMenu: TagCurMenu.updateTagCurMenu,
	},
}
</script>

<style scoped></style>
