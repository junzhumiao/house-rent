const signMap = {
    '0': '签署',
    '1': '未签署',
}

const stopMap = {
    '0': '停止',
    '1': '未停止',
}


const preColumns = ["合同编号", "房屋编号", "房东编号", "合同序列码", "创建时间"]
const signColumns = ["合同编号", "签署时间",
    "签署结束时间", "房东预存保证金", "租客预存租金", "租客预存保证金", "租客地址", '房东地址'
]


const beginColumns = ["合同编号", "合同生效时间", "合同结束时间", "合同序列号", "租客地址", "房东地址", "每月应缴纳租金"]
const stopColumns = ["合同编号", "合同序列号", "合同终止时间", "租客地址", "房东地址"]


const Type = {
    Pre: '0',
    Sign: '1',
    Begin: '2',
    Stop: '3',
}



export { signMap, stopMap, preColumns, signColumns, beginColumns, stopColumns, Type }