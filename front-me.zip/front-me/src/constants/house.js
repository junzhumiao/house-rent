const columns = ["房屋编号", "联系人", "状态", "创建时间", "联系电话", "房屋地址", "电子锁密码"]


const statusOptions = [
    {
        value: "0",
        label: "起售",
    },
    {
        value: "1",
        label: "停售",
    },
]

const statusMap = {
    "0": "起售",
    "1": "停售",
}

export {
    columns,
    statusOptions,
    statusMap
}