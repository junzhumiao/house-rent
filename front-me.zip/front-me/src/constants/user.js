
let commonMenus = [
    {
        path: '/index',
        icon: "el-icon-s-home",
        label: "首页",
    },
    {
        path: "/house",
        icon: "el-icon-house",
        label: "房屋管理",
    },
    {
        path: "/contract/pre",
        icon: "el-icon-tickets",
        label: "预发布合同管理",
    },
    {
        path: "/contract/sign",
        icon: "el-icon-document",
        label: "签署合同管理",
    },
    {
        path: "/contract/begin",
        icon: "el-icon-document-checked",
        label: "生效合同管理",
    },
    {
        path: "/contract/stop",
        icon: "el-icon-document-delete",
        label: "停止合同管理",
    },
    {
        path: "/payment",
        icon: "el-icon-paperclip",
        label: "缴费管理",
    },
]

let tenantMenus = [...commonMenus]

let landlordMenus = [...commonMenus]

let adminMenus = [
    {
        path: "/user",
        icon: "el-icon-user-solid",
        label: "用户管理",
    }
]
adminMenus.push(...commonMenus)




const columns = ["用户名称", "用户编号", "手机号码", "状态", "创建时间", "性别", "用户地址", "账户余额", '角色']
let roleOptions = [
    {
        value: "1",
        label: "管理员",
    },
    {
        value: "2",
        label: "房东",
    },
    {
        value: "3",
        label: "租客",
    },
]

const sexOptions = [
    {
        value: "0",
        label: "男",
    },
    {
        value: "1",
        label: "女",
    },
    {
        value: "2",
        label: "未知",
    },
]

const sexMap = {
    '0': '男',
    '1': '女',
    '2': '未知',
}

const sexColorMap = {
    '0': 'primary',
    '1': 'danger',
    '2': 'info',
}



export {
    roleOptions,
    landlordMenus, tenantMenus, adminMenus,
    columns, sexOptions, sexMap, sexColorMap
}