class UserConstants {
    static PASSWORD_NOT_MATCH = '密码长度要求5-20的任意字符'
    static USERNAME_NOT_MATCH = '账号长度要求2-20的任意字符'
    static NICKNAME_NOT_MATCH = '昵称长度要求2-20的任意字符'
    static PHONE_NOT_MATCH = '电话格式不合法'
    static EMAIL_NOT_MATCH = '邮箱格式不合法'
    static ACCOUNT_NOT_MATCH = '账户地址格式不合法'
    /**
 * 用户名长度限制
 */
    static USERNAME_MIN_LENGTH = 2
    static USERNAME_MAX_LENGTH = 20
    /**
     * 密码长度限制
     */
    static PASSWORD_MIN_LENGTH = 5
    static PASSWORD_MAX_LENGTH = 20
    /**
     * 手机号码格式限制
     */
    static MOBILE_PHONE_NUMBER_PATTERN = /^0{0,1}(13[0-9]|15[0-9]|14[0-9]|18[0-9])[0-9]{8}$/

    /**
     * 邮箱格式限制
     */
    static EMAIL_PATTERN = /[\w!#$%&'*+/=?^_`{|}~-]+(?:\.[\w!#$%&'*+/=?^_`{|}~-]+)*@(?:[\w](?:[\w-]*[\w])?\.)+[\w](?:[\w-]*[\w])?/
}

const statusOptions = [
    {
        value: "0",
        label: "正常",
    },
    {
        value: "1",
        label: "停用",
    },
]


const colorMap = {
    '0': 'primary',
    '1': 'danger',
}

const judgeMap = {
    '0': '否',
    '1': '是',
}

const statusMap = {
    '0': '启用',
    '1': '停用',
}



export { UserConstants, statusOptions, colorMap, judgeMap, statusMap }