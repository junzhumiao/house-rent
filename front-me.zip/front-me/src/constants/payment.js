

const columns = ["缴纳记录编号", "缴纳人账户地址", "缴纳金额", "合同序列码", "创建时间"]



export {
    columns,
}