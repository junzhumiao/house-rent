import Vue from "vue"
import Vuex from "vuex"
import $Tool from "@/utils/tool"

Vue.use(Vuex)

function deepChange(state, key, val) {
    state[key] = val
    $Tool.setStorage(key, val)
}

export default new Vuex.Store({
    state: {
        token: $Tool.getStorage("token") ? $Tool.getStorage("token") : "",
        user: null,
        curMenuList: [],
        tagList: [
            {
                path: "/index",
                name: "index",
                label: "首页",
            },
        ],
        globalSet: $Tool.getStorage("globalSet")
            ? $Tool.getStorage("globalSet")
            : {
                showLogo: true,
                naviColor: '#304156'
            },
    },
    getters: {},
    mutations: {
        changeUser(state, user) {
            state.user = user
        },
        changeToken(state, token) {
            deepChange(state, 'token', token)
        },
        login(state, { user, token }) {
            state.user = user
            deepChange(state, "token", token)
        },
        changeGlobalSet(state, obj) {
            state.globalSet = obj
            $Tool.setStorage("globalSet", obj)
        },
        updateCurMenuList(state, curMenuList) {
            state.curMenuList = curMenuList.filter((item) => {
                return item.path != "/index"
            })
        },
        updateTagList(state, tag) {
            for (let i = 0; i < state.tagList.length; i++) {
                const oTag = state.tagList[i]
                if (oTag.path == tag.path) {
                    return
                }
            }
            state.tagList.push(tag)
        },
        removeTag(state, path) {
            state.tagList = state.tagList.filter((item) => {
                return item.path != path
            })
        },
        // 修改全局配置
        updateGlobalSet(state, newSet) {
            state.globalSet = newSet
        },

    },
    actions: {},
    modules: {},
})

